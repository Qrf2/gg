import React, { useEffect, useState } from "react";
import axios from "axios";
import { BASE_URL } from "../api/api";

export default function AIChat({ token }) {
  const [models, setModels] = useState([]);
  const [selected, setSelected] = useState("");
  const [prompt, setPrompt] = useState("");
  const [history, setHistory] = useState([]);

  useEffect(() => {
    async function loadData() {
      const m = await axios.get(`${BASE_URL}/models`, { headers: { Authorization: `Bearer ${token}` } });
      setModels(m.data);

      const h = await axios.get(`${BASE_URL}/chat/history`, { headers: { Authorization: `Bearer ${token}` } });
      setHistory(h.data);
    }
    loadData();
  }, [token]);

  async function sendPrompt() {
    const res = await axios.post(
      `${BASE_URL}/chat/send`,
      { model: selected, prompt },
      { headers: { Authorization: `Bearer ${token}` } }
    );
    setHistory((h) => [...h, res.data]);
  }

  return (
    <div>
      <h2>AI Chat</h2>
      <select onChange={(e) => setSelected(e.target.value)}>
        <option>Select Model</option>
        {models.map((m) => (
          <option key={m} value={m}>
            {m}
          </option>
        ))}
      </select>
      <input value={prompt} onChange={(e) => setPrompt(e.target.value)} />
      <button onClick={sendPrompt}>Send</button>
      <pre>{JSON.stringify(history, null, 2)}</pre>
    </div>
  );
}
