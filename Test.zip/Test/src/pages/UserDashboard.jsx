import React, { useEffect, useState } from "react";
import axios from "axios";
import { BASE_URL } from "../api/api";

export default function UserDashboard({ token }) {
  const [limits, setLimits] = useState(null);

  useEffect(() => {
    async function fetchLimits() {
      const res = await axios.get(`${BASE_URL}/user/limits`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setLimits(res.data);
    }
    fetchLimits();
  }, [token]);

  return (
    <div>
      <h2>User Dashboard</h2>
      {limits ? <pre>{JSON.stringify(limits, null, 2)}</pre> : <p>Loading...</p>}
      <a href="/request">Request Access</a> | <a href="/chat">AI Chat</a> | <a href="/status">Request Status</a>
    </div>
  );
}
