import React, { useEffect, useState } from "react";
import axios from "axios";
import { BASE_URL } from "../api/api";

export default function AdminDashboard({ token }) {
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    async function loadRequests() {
      const res = await axios.get(`${BASE_URL}/admin/requests`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setRequests(res.data);
    }
    loadRequests();
  }, [token]);

  async function handleApprove(id) {
    await axios.post(`${BASE_URL}/admin/request/${id}/approve`, {}, { headers: { Authorization: `Bearer ${token}` } });
  }

  async function handleReject(id) {
    await axios.post(`${BASE_URL}/admin/request/${id}/reject`, {}, { headers: { Authorization: `Bearer ${token}` } });
  }

  return (
    <div>
      <h2>Admin Dashboard</h2>
      {requests.map((r) => (
        <div key={r.id}>
          {r.user} → {r.model} ({r.status})
          <button onClick={() => handleApprove(r.id)}>Approve</button>
          <button onClick={() => handleReject(r.id)}>Reject</button>
        </div>
      ))}
    </div>
  );
}
