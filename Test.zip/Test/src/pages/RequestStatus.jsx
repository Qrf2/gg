import React, { useEffect, useState } from "react";
import axios from "axios";
import { BASE_URL } from "../api/api";

export default function RequestStatus({ token }) {
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    async function loadRequests() {
      const res = await axios.get(`${BASE_URL}/user/requests`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setRequests(res.data);
    }
    loadRequests();
  }, [token]);

  return (
    <div>
      <h2>My Requests</h2>
      <ul>
        {requests.map((r) => (
          <li key={r.id}>
            {r.model} - {r.status}
          </li>
        ))}
      </ul>
    </div>
  );
}
