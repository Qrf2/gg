import React, { useState } from "react";
import axios from "axios";

export default function Login({ onLogin }) {
  const [Pakno, setPakno] = useState("");
  const [PasswordHash, setPasswordHash] = useState("");
  const [PType, setPType] = useState(""); // dynamic user type
  const [error, setError] = useState("");

  async function handleLogin(e) {
    e.preventDefault();
    try {
      // API #1 → Login
      const response = await axios.post(
        "https://172.32.3.12:2220/api/account/AuthPPortalOffAirCiv",
        {
          Pakno,
          PType, // now dynamic, not hardcoded
          PasswordHash,
        }
      );

      if (response.data.status !== true) {
        setError("Invalid credentials");
        return;
      }

      const token = response.data.token;
      localStorage.setItem("token", token);

      // API #3 → Profile
      const profile = await axios.get(
        "https://172.32.3.12:2220/api/account/profile",
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      onLogin({ token, ...profile.data });
    } catch (err) {
      console.error(err);
      setError("Server error");
    }
  }

  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <input
          value={Pakno}
          onChange={(e) => setPakno(e.target.value)}
          placeholder="Pakno"
        />
        <input
          type="password"
          value={PasswordHash}
          onChange={(e) => setPasswordHash(e.target.value)}
          placeholder="Password"
        />

        {/* Dropdown for PType selection */}
        <select value={PType} onChange={(e) => setPType(e.target.value)} required>
          <option value="">Select Type</option>
          <option value="1">Officer</option>
          <option value="2">Uniform</option>
          <option value="3">Civilian</option>
        </select>

        <button type="submit">Login</button>
      </form>
      {error && <p>{error}</p>}
    </div>
  );
}
