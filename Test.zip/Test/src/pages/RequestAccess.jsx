import React, { useEffect, useState } from "react";
import axios from "axios";
import { BASE_URL } from "../api/api";

export default function RequestAccess({ token }) {
  const [rules, setRules] = useState([]);
  const [models, setModels] = useState([]);
  const [form, setForm] = useState({ model: "", tokens: "", prompts: "", justification: "" });

  useEffect(() => {
    async function loadData() {
      const r = await axios.get(`${BASE_URL}/rules`, { headers: { Authorization: `Bearer ${token}` } });
      setRules(r.data);
      const m = await axios.get(`${BASE_URL}/models`, { headers: { Authorization: `Bearer ${token}` } });
      setModels(m.data);
    }
    loadData();
  }, [token]);

  async function handleSubmit(e) {
    e.preventDefault();
    await axios.post(
      `${BASE_URL}/request/submit`,
      {
        model: form.model,
        tokens: form.tokens,
        prompts: form.prompts,
        justification: form.justification,
      },
      { headers: { Authorization: `Bearer ${token}` } }
    );
    alert("Request submitted");
  }

  return (
    <div>
      <h2>Request Access</h2>
      <form onSubmit={handleSubmit}>
        <select onChange={(e) => setForm({ ...form, model: e.target.value })}>
          <option>Select Model</option>
          {models.map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </select>
        <input placeholder="Tokens" onChange={(e) => setForm({ ...form, tokens: e.target.value })} />
        <input placeholder="Prompts/day" onChange={(e) => setForm({ ...form, prompts: e.target.value })} />
        <input placeholder="Justification" onChange={(e) => setForm({ ...form, justification: e.target.value })} />
        <button type="submit">Submit</button>
      </form>
      <pre>{JSON.stringify(rules, null, 2)}</pre>
    </div>
  );
}


