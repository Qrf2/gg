import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import UserDashboard from "./pages/UserDashboard";
import RequestAccess from "./pages/RequestAccess";
import RequestStatus from "./pages/RequestStatus";
import AIChat from "./pages/AIChat";
import AdminDashboard from "./pages/AdminDashboard";

export default function App() {
  const [user, setUser] = useState(null);

  if (!user) return <Login onLogin={setUser} />;

  return (
    <Router>
      <Routes>
        {user.role === "admin" ? (
          <Route path="/*" element={<AdminDashboard token={user.token} />} />
        ) : (
          <>
            <Route path="/" element={<UserDashboard token={user.token} />} />
            <Route path="/request" element={<RequestAccess token={user.token} />} />
            <Route path="/status" element={<RequestStatus token={user.token} />} />
            <Route path="/chat" element={<AIChat token={user.token} />} />
          </>
        )}
      </Routes>
    </Router>
  );
}
