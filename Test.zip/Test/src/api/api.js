import axios from "axios";

export const BASE_URL = "https://172.32.3.12:2220/api"; // replace with actual
